#!/usr/bin/env bash
#
# Generates the TLS material required to run a Kafka broker secured with
# SASL_SSL (SCRAM-SHA-512) and to let the Microcks webapp and async-minion
# connect to it.
#
# Produced files (in ./secrets):
#   - ca.key / ca.crt              : the test Certificate Authority
#   - kafka.keystore.p12           : broker server certificate (SAN: kafka, localhost)
#   - kafka.truststore.p12         : client/broker truststore holding the CA cert
#   - credentials                  : the password shared by keystore & truststore
#   - kafka_client_jaas.properties : ready-to-use client config for kafka CLI tools
#
# The script is idempotent: it does nothing if secrets are already present.
# It only needs `keytool` (JDK) and `openssl`, both available in the Strimzi
# Kafka image, so it can be run as an init container (recommended) or locally.
#
set -euo pipefail

# Resolve directory of this script so it can be run from anywhere.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SECRETS_DIR="${SECRETS_DIR:-${SCRIPT_DIR}/secrets}"

# Tunables (overridable through environment).
STORE_PASSWORD="${STORE_PASSWORD:-microcks}"
VALIDITY_DAYS="${VALIDITY_DAYS:-3650}"
BROKER_CN="${BROKER_CN:-kafka}"
# Subject Alternative Names so the cert is valid both inside (kafka) and
# outside (localhost) the docker network.
SAN="${SAN:-DNS:kafka,DNS:localhost,IP:127.0.0.1}"

CA_KEY="${SECRETS_DIR}/ca.key"
CA_CRT="${SECRETS_DIR}/ca.crt"
KEYSTORE="${SECRETS_DIR}/kafka.keystore.p12"
TRUSTSTORE="${SECRETS_DIR}/kafka.truststore.p12"
CREDENTIALS="${SECRETS_DIR}/credentials"
CLIENT_PROPS="${SECRETS_DIR}/kafka_client_jaas.properties"

mkdir -p "${SECRETS_DIR}"

if [[ -f "${KEYSTORE}" && -f "${TRUSTSTORE}" ]]; then
  echo "[gen-certs] Secrets already present in ${SECRETS_DIR}, nothing to do."
  echo "[gen-certs] Delete the folder content to force a regeneration."
  exit 0
fi

echo "[gen-certs] Generating TLS material into ${SECRETS_DIR} ..."

# 1. Create a self-signed Certificate Authority.
openssl req -new -x509 -nodes -days "${VALIDITY_DAYS}" \
  -keyout "${CA_KEY}" -out "${CA_CRT}" \
  -subj "/CN=Microcks Test CA/O=Microcks/C=FR"

# 2. Create the broker keystore with a freshly generated key pair.
keytool -genkeypair -alias kafka \
  -keyalg RSA -keysize 2048 -validity "${VALIDITY_DAYS}" \
  -storetype PKCS12 -keystore "${KEYSTORE}" \
  -storepass "${STORE_PASSWORD}" -keypass "${STORE_PASSWORD}" \
  -dname "CN=${BROKER_CN},O=Microcks,C=FR" \
  -ext "SAN=${SAN}"

# 3. Create a CSR for the broker key, sign it with the CA.
keytool -certreq -alias kafka \
  -keystore "${KEYSTORE}" -storepass "${STORE_PASSWORD}" \
  -file "${SECRETS_DIR}/kafka.csr" -ext "SAN=${SAN}"

openssl x509 -req -CA "${CA_CRT}" -CAkey "${CA_KEY}" -CAcreateserial \
  -in "${SECRETS_DIR}/kafka.csr" -out "${SECRETS_DIR}/kafka.crt" \
  -days "${VALIDITY_DAYS}" \
  -extfile <(printf "subjectAltName=%s" "${SAN}")

# 4. Import the CA then the signed broker cert back into the keystore so the
#    chain is complete.
keytool -importcert -alias ca -noprompt \
  -keystore "${KEYSTORE}" -storepass "${STORE_PASSWORD}" \
  -file "${CA_CRT}"

keytool -importcert -alias kafka \
  -keystore "${KEYSTORE}" -storepass "${STORE_PASSWORD}" \
  -file "${SECRETS_DIR}/kafka.crt"

# 5. Build the client/broker truststore holding only the CA cert.
keytool -importcert -alias ca -noprompt \
  -keystore "${TRUSTSTORE}" -storetype PKCS12 -storepass "${STORE_PASSWORD}" \
  -file "${CA_CRT}"

# 6. Persist the shared password and a ready-to-use client config.
echo -n "${STORE_PASSWORD}" > "${CREDENTIALS}"

cat > "${CLIENT_PROPS}" <<EOF
# Client config for kafka CLI tools (kafka-console-consumer / producer).
# Usage: kafka-console-consumer.sh --bootstrap-server localhost:9092 \\
#          --consumer.config kafka_client_jaas.properties --topic <topic>
security.protocol=SASL_SSL
sasl.mechanism=SCRAM-SHA-512
sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username="microcks" password="microcks";
ssl.truststore.location=/deployments/config/kafka/truststore/kafka.truststore.p12
ssl.truststore.password=${STORE_PASSWORD}
ssl.truststore.type=PKCS12
EOF

# 7. Clean up intermediate artifacts.
rm -f "${SECRETS_DIR}/kafka.csr" "${SECRETS_DIR}/kafka.crt" "${SECRETS_DIR}/ca.srl"

echo "[gen-certs] Done. Generated files:"
ls -1 "${SECRETS_DIR}"

