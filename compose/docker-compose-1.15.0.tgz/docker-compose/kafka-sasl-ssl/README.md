# Microcks async mocking over a secured Kafka broker (SASL_SSL + SCRAM-SHA-512)

This folder provides a **self-contained Docker Compose test bench** that runs Microcks
(webapp + async-minion) against an Apache Kafka broker secured with
**`SASL_SSL`** transport and **`SCRAM-SHA-512`** authentication.

It reproduces, locally and without Kubernetes, the production setup that the Microcks
Helm chart configures when `features.async.kafka.install=false` and
`features.async.kafka.authentication.type=SASL_SSL` with `saslMechanism=SCRAM-SHA-512`.

## Why this exists

By default the Microcks Docker Compose samples connect to a **plaintext** Kafka broker.
Validating an authenticated/encrypted broker requires three additional things that this
bench wires together for you:

1. **TLS material** — a CA, a broker keystore and a client truststore.
2. **A broker configured for `SASL_SSL` + `SCRAM-SHA-512`**, including the
   provisioning of the SCRAM user credentials (these live inside the broker/ZooKeeper,
   they are not just a config file).
3. **Microcks configuration** for both the webapp (Kafka *producers*) and the
   async-minion (Kafka *consumers* + mock *producer*) so they authenticate to the broker.

## Architecture

```
                         SASL_SSL / SCRAM-SHA-512
                  ┌───────────────────────────────────────┐
                  │                                        │
   ┌──────────────▼─────────────┐         ┌────────────────┴───────────────┐
   │ microcks (webapp)          │         │ microcks-async-minion          │
   │  - service-changes producer│         │  - services-updates consumer   │
   │  - asyncapi-triggers prod. │         │  - asyncapi-triggers consumer  │
   │                            │         │  - mock message producer       │
   └──────────────┬─────────────┘         └────────────────┬───────────────┘
                  │   truststore (PKCS12)                   │
                  └─────────────────┬───────────────────────┘
                                    │
                       ┌────────────▼────────────┐
                       │ kafka (Strimzi)         │
                       │  INTERNAL      :9091  PLAINTEXT (inter-broker)
                       │  CLIENT_INTERNAL:19092 SASL_SSL (containers)
                       │  CLIENT_EXTERNAL:9092  SASL_SSL (host / CLI)
                       └────────────┬────────────┘
                                    │
                            ┌───────▼───────┐
                            │ zookeeper     │  (holds SCRAM credentials)
                            └───────────────┘
```

The broker exposes three listeners:

| Listener           | Port   | Protocol   | Used by                                  |
|--------------------|--------|------------|------------------------------------------|
| `INTERNAL`         | 9091   | PLAINTEXT  | Inter-broker traffic only                |
| `CLIENT_INTERNAL`  | 19092  | SASL_SSL   | Microcks containers (`kafka:19092`)      |
| `CLIENT_EXTERNAL`  | 9092   | SASL_SSL   | Host machine / CLI tools (`localhost:9092`) |

The `INTERNAL` listener stays PLAINTEXT on purpose: it keeps single-node bootstrap simple
by avoiding a chicken-and-egg problem where the broker would need SCRAM credentials to talk
to itself before those credentials exist.

> **Note:** Keycloak is intentionally disabled (`KEYCLOAK_ENABLED=false`) to keep the bench
> minimal and let you focus on the Kafka security path.

## Files in this folder

| File                                   | Purpose                                                                    |
|----------------------------------------|----------------------------------------------------------------------------|
| `../docker-compose-kafka-sasl-ssl.yml` | The full stack definition (Mongo, Postman, Kafka stack, webapp, minion).   |
| `gen-certs.sh`                         | Generates the CA, broker keystore and client truststore.                   |
| `server.properties`                    | Kafka broker configuration (listeners, SASL/SCRAM, TLS).                   |
| `microcks-config/application.properties` | Webapp Kafka **producers** security configuration.                       |
| `microcks-config/features.properties`  | Enables the async-api feature and the Kafka endpoint shown in the UI.      |
| `minion-config/application.properties` | Async-minion Kafka **consumers** + mock producer security configuration.   |
| `secrets/`                             | Generated TLS material (git-ignored, created on first run).                |

All credentials in this bench use the same value, `microcks` (username, SCRAM password and
keystore/truststore password). This is fine for a local POC — **do not reuse as-is in a real
environment**.

## Prerequisites

- [Docker](https://docs.docker.com/get-docker/) with the Compose plugin (`docker compose`).
- Free local ports: `8080`, `9090` (webapp), `8081` (minion), `9092` (Kafka external).
- No JDK/OpenSSL required on the host: the TLS material is generated inside a container.

## How to run

From the `install/docker-compose` directory:

```bash
docker compose -f docker-compose-kafka-sasl-ssl.yml up -d
```

On first start the orchestration performs, in order:

1. `kafka-certs` — generates `secrets/` (CA, broker keystore, client truststore).
2. `zookeeper` — starts and becomes healthy.
3. `kafka-init-scram` — provisions the `microcks` SCRAM-SHA-512 user in ZooKeeper.
4. `kafka` — starts only after both init services have completed successfully.
5. `app` (webapp) and `async-minion` — start once the broker is healthy.

Wait until the webapp is healthy:

```bash
curl -s http://localhost:8080/api/health
```

Open the UI at <http://localhost:8080> (no login required, Keycloak is disabled).

## How to test it end-to-end

### 1. Import a Kafka AsyncAPI mock

```bash
# From the repository root
curl -X POST -F "file=@samples/UserSignedUpAPI-asyncapi.yml" \
  http://localhost:8080/api/artifact/upload
```

The async-minion immediately starts publishing mock messages to the secured topic
`UsersignedupAPI-0.1.1-consumeUserSignedUp` at the configured frequency.

### 2. Verify the minion is connected to the secured broker

```bash
curl -s http://localhost:8081/q/health/ready
```

You should see the Kafka connection and both channels reported as `UP`/`[OK]`.

### 3. Consume the secured topic with the Kafka CLI

Run a console consumer from inside the broker container, using a SASL_SSL client config:

```bash
docker exec microcks-kafka bash -c '
cat > /tmp/client.properties <<EOF
security.protocol=SASL_SSL
sasl.mechanism=SCRAM-SHA-512
sasl.jaas.config=org.apache.kafka.common.security.scram.ScramLoginModule required username="microcks" password="microcks";
ssl.truststore.location=/secrets/kafka.truststore.p12
ssl.truststore.password=microcks
ssl.truststore.type=PKCS12
EOF
bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --consumer.config /tmp/client.properties \
  --topic UsersignedupAPI-0.1.1-consumeUserSignedUp \
  --timeout-ms 10000'
```

Expected output — a stream of mock events similar to:

```json
{"id":"...","sendAt":"...","fullName":"Laurent Broudoux","email":"laurent@microcks.io","age":41}
{"id":"...","sendAt":"...","fullName":"John Doe","email":"john@microcks.io","age":36}
```

> A ready-to-use client config is also generated at `secrets/kafka_client_jaas.properties`
> (its `ssl.truststore.location` points to the path used **inside the Microcks containers**;
> adjust it to `/secrets/...` when running CLI tools from within the broker container).

## Cleanup

```bash
docker compose -f docker-compose-kafka-sasl-ssl.yml down
```

To force a full reset including the regeneration of TLS material:

```bash
docker compose -f docker-compose-kafka-sasl-ssl.yml down -v
rm -rf kafka-sasl-ssl/secrets
```

## Customization

| What                         | Where                                                              |
|------------------------------|--------------------------------------------------------------------|
| Passwords / SCRAM user       | `gen-certs.sh` (`STORE_PASSWORD`), `kafka-init-scram` command, and the `*-config/*.properties` JAAS lines |
| Certificate validity / SAN   | `gen-certs.sh` (`VALIDITY_DAYS`, `SAN`, `BROKER_CN`)                |
| Broker listeners / protocols | `server.properties`                                                |
| Supported minion bindings    | `minion-config/application.properties` (`minion.supported-bindings`) |

`gen-certs.sh` is idempotent: it does nothing if `secrets/` already contains the stores.
Delete the folder to force a regeneration.

## Troubleshooting

- **`SaslAuthenticationException` in the minion/webapp logs** — the SCRAM user was not
  provisioned. Check `docker logs microcks-kafka-init-scram` for
  `Completed updating config for entity: user-principal 'microcks'`.
- **SSL handshake / `CertificateException`** — the truststore is missing or not mounted.
  Ensure `secrets/kafka.truststore.p12` exists and is mounted at
  `/deployments/config/kafka/truststore/` in both Microcks containers.
- **`LEADER_NOT_AVAILABLE` warnings** — harmless; this is the broker auto-creating the topic
  on first access.
- **Webapp stuck connecting to `localhost:27017`** — the Mongo env vars must be
  `SPRING_MONGODB_URI` / `SPRING_MONGODB_DATABASE` (already set in the compose file).

## Related resources

- Helm chart Kafka authentication reference: `install/kubernetes/README.md`
  (section *Kafka feature details*).
- Plaintext async sample for comparison: `async-addon.yml`.

